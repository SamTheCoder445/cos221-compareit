package com.compareit;

public class images {
    public int image_id;
    public int product_id;
    public String image_url;
    
}
