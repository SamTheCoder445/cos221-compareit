package com.compareit;

public class UserReview {
    public int rating;
    public String comment;
    public String date;
    public String reviewerName;
    public String reviewerEmail;
}
