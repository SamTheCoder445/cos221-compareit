package com.compareit;

public class  Brand {

     public int id;
       public String name;
    
}
