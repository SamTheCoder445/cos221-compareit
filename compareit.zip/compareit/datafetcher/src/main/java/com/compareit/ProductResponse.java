package com.compareit;

import java.util.List;

public class ProductResponse {
    public List<Product> products;
}
