package com.compareit;

public class Category {
     public int id;
       public String name;
    
}
