<?php

//define('DB_HOST', 'ballast.proxy.rlwy.net');
//define('DB_PORT', '54333');
//define('DB_NAME', 'railway');
//define('DB_USER', 'root');
//define('DB_PASSWORD', 'PTtpJXjOCWmhnEHlMXniKTLewYuTUtCR');

////////////////////////////////////////////////////////////////
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'railway');
define('DB_USER', 'root');
define('DB_PASSWORD', '0607063195');


//aFAJjochiQPROYOlrObjvGBenJMavpLe