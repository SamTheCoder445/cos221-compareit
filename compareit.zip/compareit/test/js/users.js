document.addEventListener('DOMContentLoaded', () => {
    const API_URL = '../php/api.php';
    const usersBody = document.getElementById('usersBody');
    const addUserForm = document.getElementById('addUserForm');
    const newUserEmail = document.getElementById('newUserEmail');

    loadUsers();

    function loadUsers() {
        fetch(API_URL, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ type: 'GetUsers' })
        })
        .then(res => res.json())
        .then(res => {
            usersBody.innerHTML = '';
            if (res.data && res.data.length > 0) {
                res.data.forEach(user => {
                    usersBody.innerHTML += `
                        <tr>
                            <td>${user.user_id}</td>
                            <td>${user.email}</td>
                            <td>${user.created_at}</td>
                            <td><button class="btn btn-sm btn-danger" data-id="${user.user_id}">Delete</button></td>
                        </tr>`;
                });
            } else {
                usersBody.innerHTML = `<tr><td colspan="4" class="text-center">No users found.</td></tr>`;
            }
        });
    }

    addUserForm.addEventListener('submit', e => {
        e.preventDefault();
        const email = newUserEmail.value.trim();
        if (!email) return;

        fetch(API_URL, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ type: 'AddUser', email })
        })
        .then(res => res.json())
        .then(() => {
            newUserEmail.value = '';
            loadUsers();
        });
    });

    usersBody.addEventListener('click', e => {
        if (e.target.classList.contains('btn-danger')) {
            const userId = e.target.getAttribute('data-id');
            if (confirm("Delete this user?")) {
                fetch(API_URL, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ type: 'DeleteUser', user_id: userId })
                })
                .then(res => res.json())
                .then(() => loadUsers());
            }
        }
    });
});
