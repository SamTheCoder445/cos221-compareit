document.addEventListener("DOMContentLoaded", function () {
  const url = "../php/api.php";
  const tableBody = document.getElementById("retailers-body");
  const form = document.getElementById("addRetailerForm");

  function fetchRetailers() {
    fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "GetRetailers" }),
    })
      .then((res) => res.json())
      .then((data) => renderTable(data.data))
      .catch((err) => console.error("Error fetching retailers:", err));
  }

  function renderTable(retailers) {
    tableBody.innerHTML = "";
    for (let retailer of retailers) {
      let row = document.createElement("tr");
      row.innerHTML = `
                <td>${retailer.retailer_id}</td>
                <td>${retailer.name}</td>
                <td>${retailer.created_at}</td>
                <td><button class="btn btn-danger btn-sm" data-id="${retailer.retailer_id}">Delete</button></td>
            `;
      tableBody.appendChild(row);
    }

    document.querySelectorAll("button[data-id]").forEach((btn) => {
      btn.addEventListener("click", function () {
        deleteRetailer(this.getAttribute("data-id"));
      });
    });
  }

  function deleteRetailer(id) {
    fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "DeleteRetailer", retailer_id: id }),
    })
      .then((res) => res.json())
      .then(() => fetchRetailers())
      .catch((err) => console.error("Error deleting retailer:", err));
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    const name = document.getElementById("retailerName").value.trim();
    if (!name) return;

    fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "AddRetailer", name: name }),
    })
      .then((res) => res.json())
      .then(() => {
        form.reset();
        fetchRetailers();
      })
      .catch((err) => console.error("Error adding retailer:", err));
  });

  fetchRetailers();
});
