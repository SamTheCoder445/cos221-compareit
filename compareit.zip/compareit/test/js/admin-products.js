document.addEventListener("DOMContentLoaded", () => {
  // DOM Elements
  const searchForm = document.getElementById("searchForm");
  const searchInput = document.getElementById("searchInput");
  const resultsTable = document.getElementById("resultsTable");
  const resultsBody = document.getElementById("resultsBody");
  const loadingIndicator = document.getElementById("loadingIndicator");
  const errorAlert = document.getElementById("errorAlert");
  const successAlert = document.getElementById("successAlert");
  
  // API Configuration
  const API_URL = "../php/api.php";
  const STATUS_CLASSES = {
    'in_stock': 'bg-success',
    'out_of_stock': 'bg-warning text-dark',
    'discontinued': 'bg-danger',
    'available': 'bg-primary'
  };

  // Event Listeners
  searchForm.addEventListener("submit", handleSearch);
  resultsBody.addEventListener("click", handleTableActions);

  // Search Handler
  async function handleSearch(e) {
    e.preventDefault();
    const query = searchInput.value.trim();
    if (!query) return;

    try {
      showLoading(true);
      hideAlerts();
      resultsTable.classList.add("d-none");

      const response = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "GetProducts", query })
      });

      const data = await response.json();

      if (!response.ok || data.status !== "success") {
        throw new Error(data.message || "Failed to fetch products");
      }

      if (data.products.length === 0) {
        showAlert(errorAlert, "No products found matching your search.");
        return;
      }

      renderProducts(data.products);
      resultsTable.classList.remove("d-none");
    } catch (error) {
      console.error("Search error:", error);
      showAlert(errorAlert, error.message || "An error occurred while searching.");
    } finally {
      showLoading(false);
    }
  }

  // Table Actions Handler
  async function handleTableActions(e) {
    if (e.target.classList.contains("delete-btn")) {
      const productId = e.target.dataset.id;
      if (confirm("Are you sure you want to delete this product?")) {
        try {
          showLoading(true);
          hideAlerts();

          const response = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ type: "DeleteProduct", id: productId })
          });

          const data = await response.json();

          if (!response.ok || data.status !== "success") {
            throw new Error(data.message || "Failed to delete product");
          }

          e.target.closest("tr").remove();
          showAlert(successAlert, "Product deleted successfully.");
          
          // Hide table if no products left
          if (resultsBody.children.length === 0) {
            resultsTable.classList.add("d-none");
          }
        } catch (error) {
          console.error("Delete error:", error);
          showAlert(errorAlert, error.message || "An error occurred while deleting.");
        } finally {
          showLoading(false);
        }
      }
    }
  }

  // Helper Functions
  function renderProducts(products) {
    resultsBody.innerHTML = "";
    products.forEach(product => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${product.product_id}</td>
        <td>${product.title}</td>
        <td>${product.category_id}</td>
        <td>${product.brand_id}</td>
        <td>
          <span class="badge ${getStatusClass(product.availability_status)}">
            ${formatStatus(product.availability_status)}
          </span>
        </td>
        <td>${formatDate(product.created_at)}</td>
        <td>
          <button class="btn btn-sm btn-danger delete-btn" data-id="${product.product_id}">
            Delete
          </button>
        </td>
      `;
      resultsBody.appendChild(tr);
    });
  }

  function getStatusClass(status) {
    return STATUS_CLASSES[status] || 'bg-secondary';
  }

  function formatStatus(status) {
    return status.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  }

  function formatDate(dateString) {
    return new Date(dateString).toLocaleString();
  }

  function showLoading(show) {
    if (show) {
      loadingIndicator.classList.remove("d-none");
    } else {
      loadingIndicator.classList.add("d-none");
    }
  }

  function showAlert(alertElement, message) {
    alertElement.querySelector(".alert-message").textContent = message;
    alertElement.classList.remove("d-none");
    setTimeout(() => alertElement.classList.add("d-none"), 5000);
  }

  function hideAlerts() {
    errorAlert.classList.add("d-none");
    successAlert.classList.add("d-none");
  }
});