
<?php 

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Set page title
$pageTitle = "Product Details - Compareit";

// Include header
include 'header.php';
?>
<style>
    /* PRODUCT DETAILS PAGE STYLES */

#product-container {
  max-width: 900px;
  margin: 40px auto;
  padding: 20px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
}

#product-title {
  font-size: 28px;
  color: #333;
  margin-bottom: 10px;
}

#product-rating {
  font-size: 18px;
  color: #ffaa00;
  margin-bottom: 5px;
}

#product-brand-stock {
  font-size: 14px;
  color: #777;
  margin-bottom: 15px;
}

#image-carousel {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  margin: 20px 0;
}

#carousel-img {
  max-width: 100%;
  max-height: 300px;
  border-radius: 10px;
  border: 1px solid #eee;
}

#prev-img,
#next-img {
  padding: 10px;
  background-color: #ffcc00;
  border: none;
  border-radius: 50%;
  font-size: 18px;
  cursor: pointer;
  transition: background-color 0.3s;
}

#prev-img:hover,
#next-img:hover {
  background-color: #e6b800;
}

#product-description {
  margin: 20px 0;
  font-size: 16px;
  line-height: 1.6;
}

#product-details {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 30px;
}

#product-details td {
  padding: 10px;
  border: 1px solid #eee;
  font-size: 15px;
  background-color: #fafafa;
}

/* PRICE TABLE */

#price-table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 30px;
}

#price-table th,
#price-table td {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid #eee;
}

#price-table th {
  background-color: #ffcc00;
  color: #333;
}

#price-table td button {
  padding: 6px 12px;
  background-color: #ff6600;
  color: white;
  border: none;
  border-radius: 5px;
  font-size: 14px;
  cursor: pointer;
}

#price-table td button:hover {
  background-color: #e65c00;
}

/* REVIEW SECTION */

#review-carousel {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 20px 0;
}

#review-content {
  flex: 1;
  padding: 15px;
  border: 1px solid #eee;
  border-radius: 10px;
  background-color: #f9f9f9;
  font-size: 15px;
  min-height: 80px;
}

#prev-review,
#next-review {
  padding: 8px 12px;
  background-color: #ffcc00;
  border: none;
  border-radius: 50%;
  cursor: pointer;
  font-size: 18px;
}

#prev-review:hover,
#next-review:hover {
  background-color: #e6b800;
}

/* ADD REVIEW SECTION */

#add-review-section {
  margin-top: 30px;
}

#add-review-section h4 {
  font-size: 20px;
  margin-bottom: 10px;
  color: #ff6600;
}

#review-rating {
  padding: 8px;
  font-size: 16px;
  border-radius: 5px;
  border: 1px solid #ccc;
  margin-bottom: 10px;
}

#review-comment {
  width: 100%;
  height: 100px;
  padding: 10px;
  margin-top: 10px;
  border-radius: 5px;
  border: 1px solid #ccc;
  font-size: 15px;
  resize: vertical;
}

#submit-review {
  margin-top: 10px;
  padding: 10px 20px;
  background-color: #ff6600;
  border: none;
  color: white;
  font-size: 16px;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s;
}

#submit-review:hover {
  background-color: #e65c00;
}
</style>

<div id="product-container">
    <h1 id="product-title"></h1>
    <p id="product-rating"></p>
    <p id="product-brand-stock"></p>

    <div id="image-carousel">
        <button id="prev-img">←</button>
        <img id="carousel-img" src="" alt="Product Image">
        <button id="next-img">→</button>
    </div>


    
<p id="product-description"></p>

    <table id="product-details"></table>
    


    <h3>Available Prices</h3>
    <table id="price-table">
        <thead>
            <tr><th>Retailer</th><th>Price</th><th>Action</th></tr>
        </thead>
        <tbody></tbody>
    </table>

    <h3>Customer Reviews</h3>
     <div id="review-carousel">
        <button id="prev-review">←</button>
        <div id="review-content"></div>
        <button id="next-review">→</button>
    </div>

    <div id="add-review-section">
        <h4>Leave a Review</h4>
        <select id="review-rating">
            <option value="1">⭐</option>
            <option value="2">⭐⭐</option>
            <option value="3">⭐⭐⭐</option>
            <option value="4">⭐⭐⭐⭐</option>
            <option value="5">⭐⭐⭐⭐⭐</option>
        </select>
        <textarea id="review-comment" placeholder="Write your review here..."></textarea>
        <button id="submit-review">Submit Review</button>
    </div>
</div>

<?php include 'footer.php'; ?>


<script src="../js/view.js"></script>

</body>
</html>















