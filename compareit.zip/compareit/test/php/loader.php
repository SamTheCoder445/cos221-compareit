<div id="loading-overlay">
    <div class="loader-container">
        <img src="/cos221-compareit/webapp/animations/loading_ring.gif" alt="Loading...">
    </div>
</div>
