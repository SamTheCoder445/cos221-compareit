
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Retailers - Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<div class="d-flex" style="min-height: 100vh;">
  <!-- Sidebar -->
  <div class="bg-dark text-white p-3" style="width: 300px;">
    <h4 class="text-white mb-4">CompareIt Dashboard</h4>
    <ul class="nav flex-column">
      <li class="nav-item"><a href="admin-dashboard.php" class="nav-link text-white"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
      <li class="nav-item"><a href="admin-products.php" class="nav-link text-white"><i class="bi bi-box-seam me-2"></i>Products</a></li>
      <li class="nav-item"><a href="retailers.php" class="nav-link text-white active"><i class="bi bi-graph-up-arrow me-2"></i>Retailers</a></li>
      <li class="nav-item"><a href="users.php" class="nav-link text-white"><i class="bi bi-person me-2"></i>Users</a></li>
    </ul>
  </div>

  <!-- Main Content -->
  <div class="flex-grow-1 p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2>Retailers</h2>
      <div class="dropdown">
        <button class="btn btn-light dropdown-toggle" data-bs-toggle="dropdown">
          Admin <i class="bi bi-person-circle ms-1"></i>
        </button>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="#">Logout</a></li>
        </ul>
      </div>
    </div>

    <form id="addRetailerForm" class="mb-3">
      <div class="input-group">
        <input type="text" id="retailerName" class="form-control" placeholder="Retailer Name" required>
        <button type="submit" class="btn btn-primary">Add Retailer</button>
      </div>
    </form>

    <table class="table table-bordered text-white">
      <thead class="bg-secondary">
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Created At</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody id="retailers-body"></tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../js/retailers.js"></script>
</body>
</html>
